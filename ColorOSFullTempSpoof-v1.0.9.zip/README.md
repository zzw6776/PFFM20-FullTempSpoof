# ColorOS Full Temperature Spoof

面向 ColorOS 的动态温度读数伪装模块。

模块不绑定具体机型、Android 版本、内核版本或 SoC 平台；运行时会自动枚举当前设备实际存在的
thermal zone、power_supply 温度节点和厂商温控服务，并按 `config.conf` 进行 best-effort 处理。
不支持的节点、SELinux 标签或服务会跳过并记录日志。

## 工作方式

模块在 late_start service 阶段执行一次：

1. 检查冲突模块；不校验机型、Android 版本或内核版本。
2. 枚举 `/sys/class/thermal/thermal_zone*`。
3. 根据 `type` 分类并从 `config.conf` 读取目标温度。
4. 按目标节点 SELinux 标签在 `/dev/coloros_fulltempspoof` 下动态创建独立 tmpfs，
   分别保存不同标签对应的伪造文件。
5. 将伪造文件 bind mount 到每个 `thermal_zoneN/temp`。
6. 可选处理电池 power_supply 温度与 `/proc/shell-temp`。
7. 厂商温控服务按单独配置项处理；默认全部 `keep`，不停止、不重启。
8. 验证每个节点并生成映射表后退出，不驻留后台。

跨设备使用时，模块采用 best-effort 策略：安装阶段会预检查并显示预计会跳过的
thermal zone、power_supply 节点、`/proc/shell-temp` 或厂商服务；运行阶段会把实际
跳过项记录到 `module.log`。thermal zone 数量不再写死，当前设备发现几个就处理几个。
只要至少一个 thermal zone 成功挂载，就不会因为其他入口失败而整体回滚。
默认只伪装当前值位于 10°C～130°C 的 thermal zone 和 power_supply 温度节点，
用于跳过 0、vbat 电压值、`-273000` 等明显不是正常温度读数的节点。
`type=socd` 按 ColorOS 当前机型实测的摄氏度整数节点单独处理，其余 thermal zone
仍按常见毫摄氏度节点处理。
`sdr0`、`mmw_ific0` 等会随 5G/射频活动动态上线或深度休眠的节点归入
`DYNAMIC_RADIO` 分类，默认关闭伪装，避免挂载数量随网络活动在两种状态间波动。
除分类级配置外，`config.conf` 还支持按 thermal zone 的 `type` 写 `NODE_*`
覆盖项；未配置的节点继续继承分类配置，因此模块不依赖配套 App 也可以单独使用。

伪造文件通过 tmpfs 的 `context=` 挂载参数直接获得原温度节点使用的 SELinux 标签。
当前白名单包括 `sysfs_therm`、`sysfs_thermal`、`sysfs_battery_supply`、
`sysfs_batteryinfo`、`vendor_sysfs_battery_supply` 和 `vendor_sysfs_usb_supply`。
模块不会使用 `magiskpolicy --live` 修改运行时 SELinux 策略。

## 明确不会做的事情

- 不修改任何 XML。
- 不修改 `thermal.conf`。
- 不修改 CPU/GPU 频率。
- 不写 cooling device。
- 不写 thermal zone 的 `mode`、trip point 或 `emul_temp`。
- 不包含持续温度 watchdog。

## soc_max 保护说明

即使 `/sys/class/thermal/thermal_zone0/temp` 对用户空间显示伪造值，bind mount 也不会改变内核 thermal zone 对象内部的真实温度。本模块不会修改：

```text
thermal_zone0/type=soc_max
thermal_zone0/mode=enabled
trip_point_0_type=critical
trip_point_0_temp=116500
```

因此内核临界保护仍保留。但这是最终关机保护，不等同于正常温控，也不覆盖电池、PMIC和外壳的全部风险。

## 配置

完整配置和中文注释位于 `config.conf`。默认所有类别开启：

- CPU
- GPU
- APU/NPU
- 内存/DDR
- SoC
- shell/skin
- 电池
- 充电器
- PMIC
- dynamic radio，默认关闭
- modem/RF
- connectivity
- NTC/ambient
- unknown

修改配置后重启，或在 Magisk 模块页面点击 Action 重新应用。

## 安装顺序

1. 在 Magisk 中停用或卸载 AaTempSpoof、ColorOS解除温控限制及其他温度挂载模块。
2. 重启一次，确保旧模块的 bind mount 已全部消失。
3. 安装本模块 ZIP 并重启。
4. 检查 `module.log` 和 `thermal-map.csv`；映射表中的 `mounted` 数量以当前设备实际 thermal zone 为准，跳过项会排在最上面。

如果没有先处理旧模块，本模块会因冲突检测而拒绝应用，不会强行覆盖。

## 运行时文件

```text
/data/adb/coloros_fulltempspoof/module.log
/data/adb/coloros_fulltempspoof/thermal-map.csv
/data/adb/coloros_fulltempspoof/mounts.tsv
```

## 冲突

不得与 AaTempSpoof、ColorOS解除温控限制或其他对 thermal zone 进行挂载的模块同时运行。发现冲突时，本模块会记录错误并拒绝应用，不会自动禁用其他模块。

## 恢复

- 点击 Magisk Action：临时恢复真实节点并读取状态，随后按最新配置重新应用。
- 正常重启：bind mount 自动消失。
- 卸载模块：执行 `uninstall.sh` 恢复运行时状态并清理文件。

## 风险边界

默认配置会伪装包括电池、PMIC、充电器和 soc_max 在内的全部温度入口。
Horae、MTK 或 Qualcomm 厂商温控服务默认均为 `keep`，不会被停止或重启；只有手动把对应
`*_SERVICE_MODE` 改为 `stop`、`restart` 或 `stop_then_restart` 后才会处理。内核 116.5°C critical 是最后保护，
并不是适合长期触发的工作温度；电池、充电 IC 或其他硬件也可能在到达该阈值前受损。
